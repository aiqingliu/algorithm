package function;

import base.Base;
import tool.AUtil;

/**
 * ��������
 *
 * @author liuaiqing
 */
public class F912 extends Base {

	/**
	 * sort1
	 */
	public void sort1(Integer[] g) {
		methodName = "sort1";
		message = "��������";
		info(methodName, message);
		// ���鲻Ϊ��
		if (AUtil.isNotEmpty(g)) {
			for (int i = 0; i < g.length; i++) {
				int temp = g[i];
				int j = i + 1;
				while (j < g.length) {
					if (g[j] < g[i]) {
						g[i] = g[j];
						g[j] = temp;
					}
					j++;
				}
				
			}
		}
		info(methodName, g);
	}
}
