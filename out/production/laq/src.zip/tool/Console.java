package tool;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Console {

	/**
	 * ��ʾ��Ϣ
	 * @param methodName
	 */
	public void info(Object Object) {
		Long now = System.currentTimeMillis();
		Date date = new Date(now);
		System.out.println(date + ":" + this.getClass() + ":" + Object.toString());
	}
	
	/**
	 * ��ʾ��Ϣ
	 * @param methodName
	 */
	public void info(String methodName) {
		Long now = System.currentTimeMillis();
		Date date = new Date(now);
		System.out.println(date + ":" + this.getClass() + "." + methodName + "()");
	}
	
	/**
	 * ��ʾ��Ϣ
	 * @param methodName
	 */
	public void info(String methodName, Object object) {
		Long now = System.currentTimeMillis();
		Date date = new Date(now);
		Timestamp timestamp = new Timestamp(now);
		try {
			if (object instanceof String) {
				System.out.println(timestamp + ":" + this.getClass() + "." + methodName + "()" + ":" + object);
			} else if (object instanceof String[]){
				System.out.println(timestamp + ":" + this.getClass() + "." + methodName + "()" + ":" + Arrays.toString((String[])object));
			} else if (object instanceof Object[]){
				System.out.println(timestamp + ":" + this.getClass() + "." + methodName + "()" + ":" + Arrays.toString((Object[])object));
			} else if (object instanceof List){
				System.out.println(timestamp + ":" + this.getClass() + "." + methodName + "()" + ":" + object.toString());
			} else {
				System.out.println(timestamp + ":" + this.getClass() + "." + methodName + "()" + ":" + object);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	/**
	 * ��ʾ��Ϣ
	 * @param methodName
	 */
	public void info(String methodName, String message) {
		Long now = System.currentTimeMillis();
		Date date = new Date(now);
		System.out.println(date + ":" + this.getClass() + "." + methodName + "()" + ":" + message);
	}
	
}
