package tool;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class AUtil {
	
	/**
	 * �ж϶����ǲ���Ϊ��
	 * 
	 * @param obj ����
	 * @return boolean ����ֵ
	 */
	public static boolean isEmpty(Object obj) {
		if (null == obj)
			return true;

		if (obj instanceof List<?>) {
			return ((List<?>) obj).size() <= 0;
		}

		if (obj instanceof Map<?, ?>) {
			return ((Map<?, ?>) obj).size() <= 0;
		}

		if (obj instanceof Set<?>) {
			return ((Set<?>) obj).size() <= 0;
		}

		if (obj instanceof String) {
			return ((String) obj).trim().length() <= 0;
		}

		if (obj instanceof StringBuffer) {
			return ((StringBuffer) obj).toString().length() <= 0;
		}

		if (obj instanceof Double) {
			return ((Double) obj).isNaN();
		}

		return false;
	}

	/**
	 * �ж϶����ǲ���Ϊ�ǿ�
	 * 
	 * @param obj ����
	 * @return boolean ����ֵ
	 */
	public static boolean isNotEmpty(Object obj) {
		return !isEmpty(obj);
	}
}
